#include <winsock2.h>
#include <stdio.h>

#define SERVER_PORT1 15000
#define SERVER_PORT2 15001
#define SERVER_SLEEP_TIME 100
#define ACCESS_BUFFER_SIZE 1024
#define IP_ADDRESS_LEN 16
#define NUMBER_OF_CLIENTS 2

// Initializes WinSock2 library
// Returns true if succeeded, false otherwise.
bool InitializeWindowsSockets();

int main(int argc,char* argv[])
{
    // Server address
    sockaddr_in serverAddresses[NUMBER_OF_CLIENTS];
	// Server's socket
    int serverPorts[NUMBER_OF_CLIENTS];
    serverPorts[0] = SERVER_PORT1;
    serverPorts[1] = SERVER_PORT2;
	// size of sockaddr structure
    int sockAddrLen=sizeof(struct sockaddr);
	// buffer we will use to receive client message
    char accessBuffer[ACCESS_BUFFER_SIZE];
	// variable used to store function return value
	int iResult;

    if(InitializeWindowsSockets() == false)
	{
		// we won't log anything since it will be logged
		// by InitializeWindowsSockets() function
		return 1;
	}

    for (int i = 0; i < NUMBER_OF_CLIENTS; i++) {
        memset((char*)&serverAddresses[i], 0, sizeof(serverAddresses[i]));
        serverAddresses[i].sin_family = AF_INET; /*set server address protocol family*/
        serverAddresses[i].sin_addr.s_addr = INADDR_ANY;
        serverAddresses[i].sin_port = htons(serverPorts[i]);
    }

    // create a socket
    SOCKET serverSockets[2];

    for (int i = 0; i < NUMBER_OF_CLIENTS; i++) {
        serverSockets[i] = socket(AF_INET,      // IPv4 address famly
            SOCK_DGRAM,   // datagram socket
            IPPROTO_UDP); // UDP   

        if (serverSockets[i] == INVALID_SOCKET)
        {
            printf("Creating socket failed with error: %d\n", WSAGetLastError());
            WSACleanup();
            return 1;
        }

        unsigned long mode = 1;
        iResult = ioctlsocket(serverSockets[i], FIONBIO, &mode);

        if (iResult == SOCKET_ERROR) {
            printf("Error with nonblocking socket mode!");
            closesocket(serverSockets[i]);
            WSACleanup();
            return 1;
        }
    }
    
    // Bind port number and local address to socket
    for (int i = 0; i < NUMBER_OF_CLIENTS; i++) {
        iResult = bind(serverSockets[i], (LPSOCKADDR)&serverAddresses[i], sizeof(serverAddresses[i]));

        if (iResult == SOCKET_ERROR)
        {
            printf("Socket bind failed with error: %d\n", WSAGetLastError());
            closesocket(serverSockets[i]);
            WSACleanup();
            return 1;
        }
    }
    
	printf("Simple UDP server started and waiting client messages.\n");

    timeval timeVal;
    timeVal.tv_sec = 1;
    timeVal.tv_usec = 0;

    fd_set readfds;
    FD_ZERO(&readfds);

    // Main server loop
    while(1)
    {       
        for (int i = 0; i < NUMBER_OF_CLIENTS; i++) {
            FD_SET(serverSockets[i], &readfds);
        }

        // clientAddress will be set from recvfrom
        sockaddr_in clientAddresses[NUMBER_OF_CLIENTS];
        for (int i = 0; i < NUMBER_OF_CLIENTS; i++) {
            memset(&clientAddresses[i], 0, sizeof(sockaddr_in));
        }
		
        memset(accessBuffer, 0, ACCESS_BUFFER_SIZE);

        int result = select(0, &readfds, NULL, NULL, &timeVal);

        if (result == 0) {
            // vreme za cekanje je isteklo
            printf("Waiting...\n");
            Sleep(1000);
            continue;
        }
        else if (result == SOCKET_ERROR) {
            //desila se greska prilikom poziva funkcije
            printf("Error!");
            break;
        }
        else {
            // rezultat je jednak broju soketa koji su zadovoljili uslov
            for (int i = 0; i < NUMBER_OF_CLIENTS; i++) {
                if (FD_ISSET(serverSockets[i], &readfds)) {
                    // izvrsenje operacije
                    // receive client message
                    iResult = recvfrom(serverSockets[i],
                        accessBuffer,
                        ACCESS_BUFFER_SIZE,
                        0,
                        (LPSOCKADDR)&clientAddresses[i],
                        &sockAddrLen);

                    if (iResult == SOCKET_ERROR)
                    {
                        printf("recvfrom failed with error: %d\n", WSAGetLastError());
                        continue;
                    }

                    char ipAddress[IP_ADDRESS_LEN];
                    // copy client ip to local char[]
                    strcpy_s(ipAddress, sizeof(ipAddress), inet_ntoa(clientAddresses[i].sin_addr));
                    // convert port number from TCP/IP byte order to
                    // little endian byte order
                    int clientPort = ntohs((u_short)clientAddresses[i].sin_port);

                    printf("Client connected from ip: %s, port: %d, sent: %s.\n", ipAddress, clientPort, accessBuffer);
                }
                FD_CLR(serverSockets[i], &readfds);
            }
        }
        
		// possible message processing logic could be placed here
    }

    // if we are here, it means that server is shutting down
	// close socket and unintialize WinSock2 library
    for (int i = 0; i < NUMBER_OF_CLIENTS; i++) {
        iResult = closesocket(serverSockets[i]);
        if (iResult == SOCKET_ERROR)
        {
            printf("closesocket failed with error: %ld\n", WSAGetLastError());
            return 1;
        }
    }

    iResult = WSACleanup();
    if (iResult == SOCKET_ERROR)
    {
        printf("WSACleanup failed with error: %ld\n", WSAGetLastError());
        return 1;
    }
	
	printf("Server successfully shut down.\n");
	return 0;
}

bool InitializeWindowsSockets()
{
    WSADATA wsaData;
	// Initialize windows sockets library for this process
    if (WSAStartup(MAKEWORD(2,2), &wsaData) != 0)
    {
        printf("WSAStartup failed with error: %d\n", WSAGetLastError());
        return false;
    }
	return true;
}
